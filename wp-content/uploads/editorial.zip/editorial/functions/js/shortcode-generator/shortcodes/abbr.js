wooShortcodeMeta={
	attributes:[
			{
				label:"Abbreviation",
				id:"content",
				help:"The abbreviated text.",
				isRequired:true
			},
			{
				label:"Full Text",
				id:"title",
				help:"The full, unabbreviated, text.", 
				isRequired:true
			}
			],
	defaultContent:"",
	shortcode:"abbr", 
	shortcodeType: "text-replace"
};
