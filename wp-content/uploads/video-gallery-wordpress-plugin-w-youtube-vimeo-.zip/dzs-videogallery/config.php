<?php

$zs1_config = array('ispreview' => 'off',
        'page' => 'video-gallery');