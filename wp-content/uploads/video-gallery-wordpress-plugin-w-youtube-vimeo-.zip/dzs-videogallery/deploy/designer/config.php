<?php
$config = array('ispreview' => 'off',
    'xmllocation' => '../xml/design.xml',
    'swflocation' => '../preview.swf');